from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse


def home(request):
    return HttpResponseRedirect(reverse('admin:index'))


def index(request):
    return HttpResponse('Index')
