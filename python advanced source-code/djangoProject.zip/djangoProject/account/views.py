from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
def signin(request):
    return HttpResponse('Đăng nhập')

def signup(request):
    return HttpResponse('Đăng ký')